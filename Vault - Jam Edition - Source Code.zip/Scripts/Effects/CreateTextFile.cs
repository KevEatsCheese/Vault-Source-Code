using Sirenix.OdinInspector;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateTextFile : MonoBehaviour
{
    
    [SerializeField] private string fileName;

    [MultiLineProperty(10)]
    [SerializeField] private string fileContents;
    [SerializeField] private bool isPermenant;
    public void Create()
    {
        TextFileCreator.CreateTextFile(fileName, fileContents, isPermenant);
    }
}