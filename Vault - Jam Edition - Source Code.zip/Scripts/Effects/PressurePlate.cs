using UnityEngine.Events;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public class PressurePlate : MonoBehaviour
{
    [SerializeField] private string fileName;
    private string filepath;

    [SerializeField] private UnityEvent onActivate;

    private void Start()
    {
        filepath = Application.persistentDataPath + @"\" + fileName;
    }

    public void StepOn()
    {
        if (File.Exists(filepath))
        {
            //WE DID IT
            onActivate.Invoke();
            PersistantDataManager.Save();
            File.Delete(filepath);
        }
        else
        {
            FileStream stream = File.Create(filepath);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, "1");
        }
    }
    public void StepOff()
    {
        FileStream stream = File.Open(filepath, FileMode.Open);
        BinaryFormatter formatter = new BinaryFormatter();
        string i = formatter.Deserialize(stream) as string;

        if(i == "1") //Just us
        {
            File.Delete(filepath);
        }
        else 
        {
            formatter.Serialize(stream, "1");
        }
    }
}
