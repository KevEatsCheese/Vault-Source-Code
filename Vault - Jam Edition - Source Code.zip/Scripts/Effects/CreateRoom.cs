using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateRoom : MonoBehaviour
{
    [SerializeField] private StringSO cave;

    public void Create()
    {
        RoomCreator.CreateRoom(cave);
    }
    public void Choose(StringSO scene)
    {
        RoomCreator.CreateRoom(scene);
    }
}
