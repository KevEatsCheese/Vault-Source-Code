using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerEnding : MonoBehaviour
{
    [SerializeField] private EndingSO endingSO;

    public void Trigger()
    {
        EventSystem.FireEvent(new OnEndingEvent(endingSO));
    }
    public void ChoseEnding(EndingSO ending)
    {
        EventSystem.FireEvent(new OnEndingEvent(ending));
    }
}
