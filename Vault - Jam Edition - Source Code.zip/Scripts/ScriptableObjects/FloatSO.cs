using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
[CreateAssetMenu(fileName = "NewFloat", menuName = "UTILS/Float")]
public class FloatSO : ScriptableObject
{
    public float value;
}
