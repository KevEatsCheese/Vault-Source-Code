using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewString", menuName = "UTILS/String")]
[System.Serializable]
public class StringSO : ScriptableObject { }