using UnityEngine;

[CreateAssetMenu(fileName = "NewSound", menuName = "UTILS/Sound")]
public class SoundSO : ScriptableObject
{
    [SerializeField] private AudioClip[] clips;
    public AudioClip GetRandomClip()
    {
        if (clips.Length == 0) return null;
        return clips[Random.Range(0, clips.Length)]; 
    }
}