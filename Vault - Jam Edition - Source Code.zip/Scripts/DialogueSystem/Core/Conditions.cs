using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Conditions 
{
    private static List<Condition> conditions = new List<Condition>();

    public static bool GetConditionStatus(ConditionSO condition)
    {
        if (condition == null) return true;

        if (condition.conditionType == ConditionTypes.Default)
        {
            foreach (Condition c in conditions)
            {
                if (c.condition == condition)  
                {
                    //Debug.Log(condition + "...is " + c.conditionStatus);
                    return c.conditionStatus;
                }
            }
        }
        else
        {
            //Debug.Log(condition+ "...is " + condition.ConditionMet());
            return condition.ConditionMet();
        }
        return false;
    }
    public static void SetConditionStatus(ConditionSO condition, bool conditionStatus)
    {
        foreach (Condition c in conditions)
        {
            if (c.condition == condition)
            {
                c.conditionStatus = conditionStatus;
                return;
            }
        }

        Debug.Log("set condition: " + condition.name + ". status: " + conditionStatus);

        conditions.Add(new Condition(condition, conditionStatus));
    }
    public static List<Condition> GetAllConditions() { return conditions; }
    public static void LoadAllConditions(List<SerializableCondition> newConditions)
    {
        if(newConditions == null) { return; } 
        if(newConditions.Count == 0) { return; }
        conditions.Clear();
        ConditionSO[] conditionSOs = Resources.LoadAll<ConditionSO>("Conditions");
        foreach (SerializableCondition savableCondition in newConditions)
        {
            foreach(ConditionSO conditionSO in conditionSOs)
            {
                if(conditionSO.name == savableCondition.conditionName)
                {
                    conditions.Add(new Condition(conditionSO, savableCondition.conditionStatus));
                    Debug.Log("load condition: " + conditionSO.name + ". status: " + savableCondition.conditionStatus);
                    break;
                }
            }
        }
       
    }
}
[System.Serializable]
public class Condition
{
    public ConditionSO condition;
    public bool conditionStatus;

    public Condition(ConditionSO condition, bool conditionStatus)
    {
        this.condition = condition;
        this.conditionStatus = conditionStatus;
    }
}
[System.Serializable]
public class SerializableCondition
{
    public string conditionName;
    public bool conditionStatus;
}