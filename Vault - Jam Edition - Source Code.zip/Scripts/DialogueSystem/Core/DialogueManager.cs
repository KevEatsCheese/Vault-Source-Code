using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DialogueManager : MonoBehaviour
{
    private string[] currentMessageList;
    private int messageListIndex;
    private DialogueSO currentDialogue;

    [SerializeField] private TextMeshProUGUI dialogueText;

    [SerializeField] private float typingAnimationSpeed;
    private bool textTyping;

    [SerializeField] private Button choiceButtonPrefab;
    [SerializeField] private Transform choiceHolder;

    [SerializeField] private SoundSO typeSound;

    [SerializeField] private GameObject imageBackground;
    [SerializeField] private Image image;

    [SerializeField] private GameObject dialogueUI;

    private void OnEnable()
    {
        EventSystem.Register<OnStartDialogueEvent>(OnStartDialogue);
    }
    private void OnDisable()
    {
        EventSystem.Unregister<OnStartDialogueEvent>(OnStartDialogue);
    }

    private void OnStartDialogue(OnStartDialogueEvent _event)
    {
        if(!IsViableDialogueThread(_event.dialogueSO)) { return; }

        dialogueUI.SetActive(true);
        Letterbox.instance.OpenLetterbox();
        SetCurrentMessage(_event.dialogueSO);

       
    } //Initiate Dialogue Sequence

    private void AdvanceDialogue()
    {
        EventSystem.FireEvent(eventInfo: new OnEndDialogueSequenceEvent(currentDialogue));
        if (currentDialogue.nextDialogues.Length == 0) { EndDialogue(); }
        else
        {
            foreach(Transform child in choiceHolder) { Destroy(child.gameObject); }

            List<DialogueChoice> validChoices = new List<DialogueChoice>();
            foreach(DialogueChoice choice in currentDialogue.nextDialogues)
            {
                if(IsViableDialogueThread(choice.dialogueSO)) validChoices.Add(choice);
            }

            if (validChoices.Count == 0) { EndDialogue(); }
            else if (validChoices.Count == 1)
            {
                SetCurrentMessage(validChoices[0].dialogueSO);
            }
            else
            {
                imageBackground.SetActive(false);
                foreach (DialogueChoice choice in validChoices)
                {
                    if(choice.dialogueSO == null) { continue; }
                    if (!IsViableDialogueThread(choice.dialogueSO)) { continue; }

                    Button newChoice = Instantiate(choiceButtonPrefab, choiceHolder);
                    newChoice.GetComponent<TextMeshProUGUI>().text = choice.choiceName;
                    newChoice.onClick.AddListener(() =>
                    {
                        foreach (Transform child in choiceHolder) { Destroy(child.gameObject); }
                        SetCurrentMessage(choice.dialogueSO);
                    });
                }
            }
        }
    } //End dialogue or present choices
    private void SetCurrentMessage(DialogueSO newCurrentDialogue)
    {
        currentDialogue = newCurrentDialogue;
        foreach(Condition condition in currentDialogue.conditionSetters)
        {
            Conditions.SetConditionStatus(condition.condition, condition.conditionStatus);
        }
        messageListIndex = 0;

        currentMessageList = currentDialogue.dialogueText.Trim().Split("\n");

        if (currentDialogue.soundEffect != null) { StaticAudioManager.PlaySFX(currentDialogue.soundEffect); }
        StaticAudioManager.ChangeAmbient(currentDialogue.ambient);
        StaticAudioManager.ChangeMusic(currentDialogue.music);

        imageBackground.SetActive(currentDialogue.backgroundImage != null);
        image.sprite = currentDialogue.backgroundImage;

        EventSystem.FireEvent(new OnStartDialogueSequenceEvent(currentDialogue));

        NextMessage();
    }
    private bool IsViableDialogueThread(DialogueSO dialogue)
    {
        if (dialogue.requiredConditions.Length == 0) return true;
        foreach(Condition req in dialogue.requiredConditions)
        {
            Debug.Log("req name: " + req.condition.name + ". req condition: " + req.condition.ConditionMet() + ". desired: " + req.conditionStatus);
            if (req.condition.ConditionMet() == req.conditionStatus) continue;
            //if (Conditions.GetConditionStatus(req.condition) == req.conditionStatus) continue;
            else return false;
        }
        return true;
    } //Check if we have req conditions to run dialogue
    private void NextMessage()
    {
        if(textTyping)
        {
            StopAllCoroutines();
            textTyping = false;
            //dialogueText.text = currentMessageList[messageListIndex - 1];
            dialogueText.text = currentMessageList[messageListIndex - 1];
            return;
        }

        //was >=
        if (messageListIndex == currentMessageList.Length)//currentMessageList.Length)
        {
            AdvanceDialogue();
            return;
        }
        
        StartCoroutine(TextAnimation(currentMessageList[messageListIndex]));
        messageListIndex++;
    } //End Type animation or AdvanceDialogue()

    private IEnumerator TextAnimation(string text)
    {
        textTyping = true;
        dialogueText.text = "";
        foreach(char c in text.ToCharArray())
        {
            StaticAudioManager.PlaySFX(typeSound);
            dialogueText.text += c;
            yield return new WaitForSeconds(1/typingAnimationSpeed);
        }
        textTyping = false;
    } //Animate Text

    private void EndDialogue() //Terminate Dialogue Sequence
    {
        StopAllCoroutines();
        StaticFunctions.DestroyChildren(choiceHolder);
        dialogueText.text = "";
        EventSystem.FireEvent(new OnEndDialogueEvent(currentDialogue));
        currentDialogue = null;
        messageListIndex = 0;
        dialogueUI.SetActive(false);
        Letterbox.instance.CloseLetterbox();
    }

    private void Update()
    {
        if(currentDialogue == null) { return; }

        if(Input.GetKeyDown(KeyCode.Space))
        {
            NextMessage();
        }
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            //EndDialogue();
        }
    }
}


public class OnStartDialogueEvent : EventInfo
{
    public DialogueSO dialogueSO;
    public OnStartDialogueEvent(DialogueSO dialogueSO)
    {
        this.dialogueSO = dialogueSO;
    }
}
public class OnStartDialogueSequenceEvent : EventInfo
{
    public DialogueSO dialogueSO;
    public OnStartDialogueSequenceEvent(DialogueSO dialogue)
    {
        this.dialogueSO = dialogue;
    }
}
public class OnEndDialogueSequenceEvent : EventInfo
{
    public DialogueSO dialogueSO;
    public OnEndDialogueSequenceEvent(DialogueSO dialogueSO)
    {
        this.dialogueSO = dialogueSO;
    }
}
public class OnEndDialogueEvent : EventInfo
{
    public DialogueSO dialogueSO;
    public OnEndDialogueEvent(DialogueSO dialogue)
    {
        this.dialogueSO = dialogue;
    }
}
