using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class DialogueResponseEvent : DialogueResponse
{
    [SerializeField] private DialogueSOEventPair[] onStartDialogue;
    [SerializeField] private DialogueSOEventPair[] onStartDialogueSequence;
    [SerializeField] private DialogueSOEventPair[] onEndDialogueSequence;
    [SerializeField] private DialogueSOEventPair[] onEndDialogue;

    public override void OnStartDialogue(OnStartDialogueEvent _event)
    {
        base.OnStartDialogue(_event);
        CheckPairs(onStartDialogue, _event.dialogueSO);
    }
    public override void OnStartDialogueSequence(OnStartDialogueSequenceEvent _event)
    {
        base.OnStartDialogueSequence(_event);
        CheckPairs(onStartDialogueSequence, _event.dialogueSO);
    }
    public override void OnEndDialogueSequence(OnEndDialogueSequenceEvent _event)
    {
        base.OnEndDialogueSequence(_event);
        CheckPairs(onEndDialogueSequence, _event.dialogueSO);
    }
    public override void OnEndDialogue(OnEndDialogueEvent _event)
    {
        base.OnEndDialogue(_event);
        CheckPairs(onEndDialogue, _event.dialogueSO);
    }

    private void CheckPairs(DialogueSOEventPair[] pairs, DialogueSO dialogueSO)
    {
        foreach (DialogueSOEventPair pair in pairs)
        {
            if (pair.dialogueSO == dialogueSO)
            {
                pair.unityEvent.Invoke();
            }
        }
    }
}
[System.Serializable]
public class DialogueSOEventPair
{
    public DialogueSO dialogueSO;
    public UnityEvent unityEvent;
}