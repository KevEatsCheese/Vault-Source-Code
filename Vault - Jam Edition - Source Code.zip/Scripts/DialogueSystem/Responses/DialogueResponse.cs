using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueResponse : MonoBehaviour
{
    public void OnEnable()
    {
        EventSystem.Register<OnStartDialogueEvent>(OnStartDialogue);
        EventSystem.Register<OnStartDialogueSequenceEvent>(OnStartDialogueSequence);
        EventSystem.Register<OnEndDialogueSequenceEvent>(OnEndDialogueSequence);
        EventSystem.Register<OnEndDialogueEvent>(OnEndDialogue);
    }
    public void OnDisable()
    {
        EventSystem.Unregister<OnStartDialogueEvent>(OnStartDialogue);
        EventSystem.Unregister<OnStartDialogueSequenceEvent>(OnStartDialogueSequence);
        EventSystem.Unregister<OnEndDialogueSequenceEvent>(OnEndDialogueSequence);
        EventSystem.Unregister<OnEndDialogueEvent>(OnEndDialogue);
    }

    public virtual void OnStartDialogue(OnStartDialogueEvent _event)
    {

    }
    public virtual void OnStartDialogueSequence(OnStartDialogueSequenceEvent _event)
    {

    }
    public virtual void OnEndDialogueSequence(OnEndDialogueSequenceEvent _event)
    {

    }
    public virtual void OnEndDialogue(OnEndDialogueEvent _event)
    {

    }
}
