using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartDialogue : MonoBehaviour
{
    [SerializeField] private DialogueSO dialogue;
    [SerializeField] private bool onStart = true;
    private void Start()
    {
        if(!onStart) { return; }
        EventSystem.FireEvent(new OnStartDialogueEvent(dialogue));
    }
    public void Choose(DialogueSO dialogueSO)
    {
        EventSystem.FireEvent(new OnStartDialogueEvent(dialogueSO));
    }
    public void Trigger()
    {
        EventSystem.FireEvent(new OnStartDialogueEvent(dialogue));
    }
}