using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Sirenix.OdinInspector;

[CreateAssetMenu(fileName = "NewDialogue", menuName = "DialogueSystem/Dialogue")]
public class DialogueSO : ScriptableObject
{
    [TabGroup("Text")]
    [HideLabel]
    [MultiLineProperty(15)]
    public string dialogueText;
    
    [TabGroup("Conditions")]
    public Condition[] requiredConditions;

    [TabGroup("Conditions")]
    public Condition[] conditionSetters;

    [TabGroup("StartEnd")]
    public DialogueChoice[] nextDialogues;

    [TabGroup("StartEnd")]
    public AudioClip music;

    [TabGroup("StartEnd")]
    public AudioClip ambient;

    [TabGroup("StartEnd")]
    public SoundSO soundEffect;

    [TabGroup("StartEnd")]
    public Sprite backgroundImage;
}

[System.Serializable] 
public class DialogueChoice
{
    public DialogueSO dialogueSO;
    public string choiceName;
}