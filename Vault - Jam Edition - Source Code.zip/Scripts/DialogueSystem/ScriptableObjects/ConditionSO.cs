using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "NewCondition", menuName = "DialogueSystem/Condition")]
public class ConditionSO : ScriptableObject
{
    public ConditionTypes conditionType;
    public Condition[] conditions;

    public bool ConditionMet()
    {
        if (conditionType == ConditionTypes.Default)
        {
            return Conditions.GetConditionStatus(this);
        }
        else if (conditionType == ConditionTypes.Either)
        {
            foreach (Condition condition in conditions)
            {
                if (Conditions.GetConditionStatus(condition.condition) == condition.conditionStatus)
                {
                    return true;
                }
            }
            return false;
        }
        else if (conditionType == ConditionTypes.And)
        {
            foreach (Condition condition in conditions)
            {
                if (Conditions.GetConditionStatus(condition.condition) != condition.conditionStatus)
                {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}
public enum ConditionTypes
{
    Default,
    Either,
    And
}