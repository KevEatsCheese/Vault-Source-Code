using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class ButtonExtension : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] private SoundSO mouseOn;
    [SerializeField] private SoundSO mouseClick;

    private TextMeshProUGUI text;

    private void Awake()
    {
        text = GetComponent<TextMeshProUGUI>();
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    public void OnPointerEnter(PointerEventData data)
    {
        if(!GetComponent<Button>().interactable) { return; }
        StaticAudioManager.PlaySFX(mouseOn);
        text.fontStyle = FontStyles.Bold;
        text.fontStyle = FontStyles.Underline; 
    }
    public void OnPointerExit(PointerEventData data)
    {
        if (!GetComponent<Button>().interactable) { return; }
        text.fontStyle = FontStyles.Normal;
    }
    private void OnClick()
    {
       // if (!GetComponent<Button>().interactable) { return; }
        StaticAudioManager.PlaySFX(mouseClick);
    }
}
