using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class InteractibleUI : MonoBehaviour
{
    public static InteractibleUI instance { get; private set; }
    [SerializeField] private TextMeshProUGUI promptText;

    private void Awake()
    {
        instance = this; 
    }

    public void ShowPrompt(string prompt) { promptText.text = "F: " + prompt; }
    public void HidePrompt() { promptText.text = ""; }
}
