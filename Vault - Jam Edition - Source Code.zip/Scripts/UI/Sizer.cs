using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using TMPro;
using UnityEngine;

public class Sizer : MonoBehaviour
{
    public float size = 5f;

    private void OnEnable()
    {
        EventSystem.Register<OnChangeResolutionEvent>(Resize);
        Resize(new OnChangeResolutionEvent());
    }
    private void OnDisable()
    {
        EventSystem.Unregister<OnChangeResolutionEvent>(Resize);
    }

    public virtual void Resize(OnChangeResolutionEvent _event) { }
}

public class OnChangeResolutionEvent : EventInfo { }
