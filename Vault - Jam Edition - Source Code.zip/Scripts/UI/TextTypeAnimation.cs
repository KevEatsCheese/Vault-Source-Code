using System.Collections;
using UnityEngine;
using TMPro;

[RequireComponent(typeof(TextMeshProUGUI))]
public class TextTypeAnimation : MonoBehaviour
{
    private string textData;
    private TextMeshProUGUI textObject;
    [SerializeField] private float textSpeed = 20;

    private void OnEnable()
    {
        textObject = GetComponent<TextMeshProUGUI>();
        textData = textObject.text;
        textObject.text = "";
        StartCoroutine(TypeAnimation());
    }
    private void OnDisable()
    {
        StopAllCoroutines();
    }
    private IEnumerator TypeAnimation()
    {
        foreach(char c in textData.ToCharArray())
        {
            textObject.text += c;
            yield return new WaitForSeconds(1f/textSpeed);
        }
    }
}
