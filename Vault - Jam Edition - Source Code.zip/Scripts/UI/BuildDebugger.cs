using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class BuildDebugger : MonoBehaviour
{
    public static BuildDebugger instance { get; private set; }

    [SerializeField] private GameObject debugPanel;
    [SerializeField] private TextMeshProUGUI textPrefab;

    private void Awake()
    {
        instance = this;
    }

    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.K))
        {
            debugPanel.SetActive(!debugPanel.activeInHierarchy);
        }
    }

    public void Debug(string message)
    {
        foreach(Transform child in debugPanel.transform)
        {
            if (child.GetComponent<TextMeshProUGUI>().text == message) return;
        }
        TextMeshProUGUI debug = Instantiate(textPrefab, debugPanel.transform);
        debug.text = message;
        Destroy(debug.gameObject, 5f);
    }
}
public static class StaticBuildDebugger
{
    public static void Debug(string message)
    {
        if (BuildDebugger.instance == null) return;
        BuildDebugger.instance.Debug(message);  
    }
}
