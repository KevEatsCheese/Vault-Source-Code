using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Collections;

public class EndingUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI header;
    [SerializeField] private TextMeshProUGUI subtext;
    [SerializeField] private TextMeshProUGUI index;
    [SerializeField] private Slider progressSlider;

    [SerializeField] private StringSO finalMessage;

    private void Start()
    {
        header.text = StaticEndingManager.currentEnding.endTitlecard;
        subtext.text = StaticEndingManager.currentEnding.endSubtext;
        index.text = "Ending: " + StaticEndingManager.currentEnding.endingIndex.ToString();

        progressSlider.maxValue = StaticEndingManager.allEndings.Length;
        progressSlider.value = PersistantData.foundEndings.Count;

        Directory.Delete(Filepaths.GetSceneDirectory(Filepaths.SCENES_TEMPORARY_FOLDER_NAME), true);
    }

    public void Continue()
    {
        StaticBuildDebugger.Debug(PersistantData.foundEndings.Count + "/" + StaticEndingManager.allEndings.Length);
        if (PersistantData.foundEndings.Count == StaticEndingManager.allEndings.Length)
        {
            PersistantDataManager.Delete();
            TKSceneManager.LoadScene(new SceneLoadData(finalMessage));
        }
        else
        {
            Application.Quit();
        }
    }
}
