using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.Events;

public class InputFieldListener : MonoBehaviour
{
    [SerializeField] private InputAction[] inputActions;
        
    private void Start()
    {
        GetComponent<TMP_InputField>().onEndEdit.AddListener(OnChangeInput);
    }
    private void OnChangeInput(string input)
    {
        foreach(InputAction inputAction in inputActions)
        {
            if(!inputAction.isCaseSensitive)
            {
                input.ToUpper();
                inputAction.input.ToUpper();
            }

            if(input == inputAction.input)
            {
                inputAction.action.Invoke();
                return;
            }
        }
    }
}
[System.Serializable]
public class InputAction 
{
    public string input;
    public bool isCaseSensitive;
    public UnityEvent action;
}