using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class SizeTexts : Sizer
{
    [SerializeField] private List<TextMeshProUGUI> texts = new List<TextMeshProUGUI>();

    public override void Resize(OnChangeResolutionEvent _event)
    {
        base.Resize(_event);
        foreach (TextMeshProUGUI text in texts)
        {
            text.fontSizeMax = size * (Screen.height / 100);
        }
    }
}
