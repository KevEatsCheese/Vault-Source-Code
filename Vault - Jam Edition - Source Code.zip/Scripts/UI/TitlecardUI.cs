using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitlecardUI : MonoBehaviour
{
    [SerializeField] private GameObject titlecardUI;
    [SerializeField] private StringSO forestScene;

    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            CloseTitlecard();
        }
    }
    private void CloseTitlecard()
    {
        titlecardUI.SetActive(false);
        TKSceneManager.LoadScene(new SceneLoadData(forestScene));
    }
}
