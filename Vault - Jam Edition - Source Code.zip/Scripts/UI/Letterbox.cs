using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Letterbox : MonoBehaviour
{
    public static Letterbox instance { get; private set; }

    private Animator animator;
    private const string OPEN_LETTERBOX_TRIGGER = "Open";
    private const string CLOSE_LETTERBOX_TRIGGER = "Close";


    private void Awake()
    {
        instance = this;
        animator = GetComponent<Animator>();    
    }

    public void OpenLetterbox()
    {
        animator.SetTrigger(OPEN_LETTERBOX_TRIGGER);
    }
    public void CloseLetterbox()
    {
        animator.SetTrigger(CLOSE_LETTERBOX_TRIGGER);
    }
}
