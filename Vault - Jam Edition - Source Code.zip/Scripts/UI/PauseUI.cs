using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseUI : MonoBehaviour
{
    [SerializeField] private GameObject pauseUI;
    [SerializeField] private GameObject optionsUI;

    [SerializeField] private StringSO menuScene;

    public void Pause()
    {
        pauseUI.SetActive(true);
        EventSystem.FireEvent(new OnPauseEvent(true));
    }
    public void Resume()
    {
        pauseUI.SetActive(false);
        EventSystem.FireEvent(new OnPauseEvent(false));
    }
    public void Options()
    {
        pauseUI.SetActive(false);
        optionsUI.SetActive(true);
    }
    public void Quit()
    {
        //DataManager.Save();
        TKSceneManager.LoadScene(new SceneLoadData(menuScene));
    }
}
public class OnPauseEvent : EventInfo
{
    public bool isPaused;

    public OnPauseEvent(bool isPaused)
    {
        this.isPaused = isPaused;
    }
}