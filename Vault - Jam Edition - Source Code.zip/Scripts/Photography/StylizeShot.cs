using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using Sirenix.OdinInspector;
using Sirenix.Utilities.Editor;
using Sirenix.OdinInspector.Editor;

public class StylizeShot : MonoBehaviour
{
    [SerializeField] private Camera cam;
  
    public ColorPalette palette;
    [SerializeField] private RawImage image;

    private string path = @"\" + "Visuals" + @"\" + "StylizedShots" + @"\";
    [SerializeField] private string shotName;


    private Color rawColor;
    private Color closestColor;

    float pendingDistance;
    float bestDistance;
    
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            StopAllCoroutines();
            StartCoroutine(Capture());
        }
        if(Input.GetKeyDown(KeyCode.T))
        {
            image.gameObject.SetActive(!image.gameObject.activeInHierarchy);
        }
    }
    private IEnumerator Capture()
    {
        if (image.texture != null) { Object.Destroy(image.texture); }

        RenderTexture rt = cam.activeTexture;
        Texture2D texture = new Texture2D(800, 800, TextureFormat.RGB24, false);
        RenderTexture.active = rt;
        texture.ReadPixels(new Rect(0, 0, rt.width, rt.height), 0, 0);
        texture.Apply();

        yield return new WaitForEndOfFrame();

        for (int x = 0; x < texture.width; x++)
        {
            for (int y = 0; y < texture.height; y++)
            {
                rawColor = texture.GetPixel(x, y);
                closestColor = palette.Colors[0];
                foreach (Color c in palette.Colors)
                {
                    pendingDistance = Vector3.Distance(ColorToVector(rawColor), ColorToVector(c));
                    bestDistance = Vector3.Distance(ColorToVector(rawColor), ColorToVector(closestColor));

                    if (pendingDistance < bestDistance)
                    {
                        closestColor = c;
                    }
                }
                texture.SetPixel(x, y, closestColor);
            }
        }
        texture.Apply();
        if(shotName == "") { shotName = Random.Range(0, 100).ToString(); }
        File.WriteAllBytes(Application.dataPath + path + shotName + ".png",texture.EncodeToPNG());
        image.texture = texture;
        image.gameObject.SetActive(true);
    }
    private Vector3 ColorToVector(Color color) { return new Vector3(color.r, color.g, color.b); }
}
