using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Escape_OnPlayerEnterActivity : Escape_OnPlayerEnter
{
    [SerializeField] private GameObject subject;
    public override void OnEnter(Transform player)
    {
        base.OnEnter(player);
        subject.SetActive(true);
    }
    public override void OnExit(Transform player)
    {
        base.OnExit(player);
        subject.SetActive(false);
    }
}
