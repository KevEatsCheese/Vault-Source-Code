using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Escape_Spawner : MonoBehaviour
{
    [SerializeField] private Escape_EnemyAI enemyPrefab;
    [SerializeField] private Transform player;
    [SerializeField] private float speed;

    private void OnEnable()
    {
        EventSystem.Register<OnEscapeGameOverEvent>(GameOver);
    }
    private void OnDisable()
    {
        EventSystem.Unregister<OnEscapeGameOverEvent>(GameOver);
    }

    private void GameOver(OnEscapeGameOverEvent _event)
    {
        CancelInvoke();
    }

    private void Start()
    {
        InvokeRepeating("Spawn",2,speed);
    }
    private void OnDestroy()
    {
        CancelInvoke();
    }
    private void Spawn()
    {
        if(Physics2D.OverlapCircle(transform.position, 0.3f)) { return; }
        Escape_EnemyAI newEnemy = Instantiate(enemyPrefab, transform);
        newEnemy.SetPlayer(player, speed);
    }
}
