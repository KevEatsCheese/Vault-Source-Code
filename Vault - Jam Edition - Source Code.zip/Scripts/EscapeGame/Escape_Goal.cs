using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Escape_Goal : MonoBehaviour
{
    [SerializeField] private Transform player;

    private void Update()
    {
        if(player.position == transform.position)
        {
            EventSystem.FireEvent(new OnEscapeGameOverEvent(true));
            Destroy(gameObject);
        }
    }
}
