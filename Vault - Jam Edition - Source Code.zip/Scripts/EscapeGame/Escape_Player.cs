using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Escape_Player : MonoBehaviour
{
    [SerializeField] private SoundSO moveSound;

    private void OnEnable()
    {
        EventSystem.Register<OnEscapeGameOverEvent>(GameOver);
    }
    private void OnDisable()
    {
        EventSystem.Unregister<OnEscapeGameOverEvent>(GameOver);
    }

    private void GameOver(OnEscapeGameOverEvent _event)
    {
        Destroy(gameObject);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.W)) { Move(Vector2.up); }
        if (Input.GetKeyDown(KeyCode.A)) { Move(Vector2.left); }
        if (Input.GetKeyDown(KeyCode.S)) { Move(Vector2.down); }
        if (Input.GetKeyDown(KeyCode.D)) { Move(Vector2.right); }
    }
    private void Move(Vector3 moveDir)
    {
        if (!Physics2D.OverlapCircle(transform.position + moveDir, 0.3f))
        {
            StaticAudioManager.PlaySFX(moveSound);
            transform.position += moveDir;
        }
    }
}
