using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Escape_EndManager : MonoBehaviour
{
    [SerializeField] private UnityEvent onGameOver;

    private void OnEnable()
    {
        EventSystem.Register<OnEscapeGameOverEvent>(GameOver);
    }
    private void OnDisable()
    {
        EventSystem.Unregister<OnEscapeGameOverEvent>(GameOver);
    }

    private void GameOver(OnEscapeGameOverEvent _event)
    {
        onGameOver.Invoke();
    }
}
public class OnEscapeGameOverEvent : EventInfo 
{
    public bool win;
    public OnEscapeGameOverEvent(bool win)
    {
        this.win = win;
    }
}