using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Escape_OnPlayerEnter : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.GetComponent<Escape_Player>()==null) { return; }
        OnEnter(collision.transform);
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.GetComponent<Escape_Player>() == null) { return; }
        OnExit(collision.transform);
    }

    public virtual void OnEnter(Transform player)
    {

    }
    public virtual void OnExit(Transform player)
    {

    }
}
