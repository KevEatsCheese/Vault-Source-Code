using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class Escape_EnemyAI : MonoBehaviour
{
    private Transform player;
    private float speed;
    [SerializeField] private SoundSO moveSound;

    private void OnEnable()
    {
        EventSystem.Register<OnEscapeGameOverEvent>(GameOver);
    }
    private void OnDisable()
    {
        EventSystem.Unregister<OnEscapeGameOverEvent>(GameOver);
    }

    private void GameOver(OnEscapeGameOverEvent _event)
    {
        CancelInvoke();
        Destroy(gameObject);
    }

    private void Start()
    {
        InvokeRepeating("Move", speed, speed);
    }
    private void OnDestroy()
    {
        CancelInvoke();
    }
    public void SetPlayer(Transform player, float speed) 
    { 
        this.player = player; 
        this.speed = speed;
    }
    private void Move()
    {
        if (transform.position == player.position)
        {
            EventSystem.FireEvent(new OnEscapeGameOverEvent(false));
            return;
        }

        Vector3 moveDir = new Vector3();
        Vector3 rawDirection = (player.position - transform.position).normalized;

        if(rawDirection.x > 0) { moveDir.x = 1; }
        else if(rawDirection.x < 0) { moveDir.x = -1; }
        if(rawDirection.y > 0) { moveDir.y = 1; }
        else if (rawDirection.y < 0) { moveDir.y = -1; }

        if (Physics2D.OverlapCircleAll(transform.position, 0.4f).Length > 1)
        {
            transform.position += new Vector3(Mathf.RoundToInt(UnityEngine.Random.Range(-1, 1)), Mathf.RoundToInt(UnityEngine.Random.Range(-1, 1)));
        }
        else
        {
            Collider2D c = Physics2D.OverlapPoint(transform.position + moveDir);

            if (c == null || c == player)
            { 
                transform.position += moveDir;
            }
        }
    }
}
