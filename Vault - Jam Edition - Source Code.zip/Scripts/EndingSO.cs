using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu()]
public class EndingSO : ScriptableObject
{
    public string endTitlecard;

    public int endingIndex;

    [Multiline(5)]
    public string endSubtext;
}
