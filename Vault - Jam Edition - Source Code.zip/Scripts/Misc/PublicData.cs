using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PublicData : MonoBehaviour
{
    public static PublicData instance { get; private set; }

    private void Awake()
    {
        instance = this;
    }
}
public static class StaticData
{
    public static StringSO lastScene { get; set; }
}