using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Filepaths 
{
    //Resources Folder Names
    public const string RESOURCES_SCENES_FOLDER_NAME = "Scenes";
    public const string RESOURCES_STARTUP_RESPONSES_FOLDER_NAME = "Startup";
    public const string RESOURCES_ENDINGS_FOLDER_NAME = "Endings";

    //Directory File Names
    public const string SCENES_FOLDER_NAME = "ROOMS";
    public const string SCENES_TEMPORARY_FOLDER_NAME = "Temporary";
    public const string SCENES_PERMENANT_FOLDER_NAME = "Permenant";

    public static string GetSceneDirectory(string specific) { return Application.dataPath + @"\" + SCENES_FOLDER_NAME + @"\" + specific; }

    //File Names
    public const string LAST_SCENE_FILE_NAME = "lastscene.dat";
    public const string PERSISTANT_DATA_FILE_NAME = "persistantdata.dat";

    //Custom Extensions
    public const string EXTENSION_SCENE = ".scene";
}
