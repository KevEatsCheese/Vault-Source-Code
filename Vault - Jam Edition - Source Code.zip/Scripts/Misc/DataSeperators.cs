using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataSeperators : MonoBehaviour
{
    public const string SEPERATOR_1 = "`";
}
