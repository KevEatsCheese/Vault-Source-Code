using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReadTexturePixelCountTest : MonoBehaviour
{
    [SerializeField] private Texture2D subject;

    private void Start()
    {
        foreach(Color c in subject.GetPixels())
        {
            Debug.Log(c);
        }
        Debug.Log(subject.GetPixels().Length);
    }
}
