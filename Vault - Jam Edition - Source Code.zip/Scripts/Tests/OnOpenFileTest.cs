using UnityEngine;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public class OnOpenFileTest : MonoBehaviour
{
    void Start()
    {
        //string[] args = System.Environment.CommandLineArgs();
        string[] args = Environment.GetCommandLineArgs();

        for (int i = 1; i < args.Length; i++)
        {
            string[] fileTypeRaw = args[i].Split(".");
            string fileType = fileTypeRaw[fileTypeRaw.Length - 1];  

            StaticBuildDebugger.Debug(args[i]);
            StaticBuildDebugger.Debug("FileType: " + fileType);

            if(fileType == "map")
            {
                if (!File.Exists(args[i])) { return; }
                BinaryFormatter saveDataFormatter = new BinaryFormatter();
                FileStream saveDataStream = File.Open(args[i], FileMode.Open);
                BasicData data = saveDataFormatter.Deserialize(saveDataStream) as BasicData;
                saveDataStream.Close();

                StaticBuildDebugger.Debug(data.stringData);
            }
        }
    }
}