using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public class CreateFileTest : MonoBehaviour
{
    public void Start()
    {
        if(!File.Exists(@"C:\New Folder"))
        {
            FileStream fix = File.Create(@"C:\New Folder");
        }
        FileStream stream = File.Create(@"C:\New Folder\hi.map");
        BinaryFormatter formatter = new BinaryFormatter();
        BasicData data = new BasicData();

        data.stringData = "WOOO";

        formatter.Serialize(stream, data);
        stream.Close();
    }
}
[System.Serializable]
public class BasicData
{
    public string stringData;
}


/* SAVE
 string filepath = Path.Combine(Application.persistentDataPath, FILE_NAME);
FileStream saveDataStream = File.Create(filepath);
BinaryFormatter saveDataformatter = new BinaryFormatter();
GameData gameData = new GameData();

saveDataformatter.Serialize(saveDataStream, gameData);
saveDataStream.Close(); */

/* LOAD
 string filepath = Path.Combine(Application.persistentDataPath, FILE_NAME);
        if (!File.Exists(filepath)) return;
        BinaryFormatter saveDataFormatter = new BinaryFormatter();
        FileStream saveDataStream = File.Open(filepath, FileMode.Open);
        GameData gameData = saveDataFormatter.Deserialize(saveDataStream) as GameData;
        saveDataStream.Close();
*/