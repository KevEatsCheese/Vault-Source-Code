using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class EndingManager : MonoBehaviour
{
    [SerializeField] private StringSO endScene;

    private void OnEnable()
    {
        EventSystem.Register<OnEndingEvent>(OnEnding);
    }
    private void OnDisable()
    {
        EventSystem.Unregister<OnEndingEvent>(OnEnding);
    }

    private void Awake()
    {
        StaticEndingManager.allEndings = Resources.LoadAll<EndingSO>(Filepaths.RESOURCES_ENDINGS_FOLDER_NAME);
    }

    private void OnEnding(OnEndingEvent _event)
    {
        //ERROR WITH SOMMAT
        if(!PersistantData.foundEndings.Contains(_event.endingSO)) { PersistantData.foundEndings.Add(_event.endingSO); }
        PersistantDataManager.Save();

        StaticEndingManager.currentEnding = _event.endingSO;

        //Directory.Delete(Filepaths.GetSceneDirectory(Filepaths.SCENES_TEMPORARY_FOLDER_NAME), true);

        TKSceneManager.LoadScene(new SceneLoadData(endScene));
    }
}
public static class StaticEndingManager
{
    public static EndingSO[] allEndings { get; set; }
    public static EndingSO currentEnding { get; set; }
}
public class OnEndingEvent : EventInfo
{
    public EndingSO endingSO;

    public OnEndingEvent(EndingSO endingSO)
    {
        this.endingSO = endingSO;
    }
}