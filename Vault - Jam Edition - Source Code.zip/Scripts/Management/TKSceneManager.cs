using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Events;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class TKSceneManager 
{
    private static SceneLoadData currentSceneLoadOperation;
    private static StringSO currentScene;
    public static void LoadScene(SceneLoadData sceneLoadData)
    {
        StaticData.lastScene = sceneLoadData.sceneToLoad;

        //Save last room
        string filepath = Application.persistentDataPath + @"\" + Filepaths.LAST_SCENE_FILE_NAME;
        FileStream saveDataStream = File.Create(filepath);
        BinaryFormatter saveDataformatter = new BinaryFormatter();
        saveDataformatter.Serialize(saveDataStream, StaticData.lastScene.name);
        saveDataStream.Close();

        EventSystem.FireEvent(new OnStartSceneLoadEvent());

        currentSceneLoadOperation = sceneLoadData;
        currentScene = currentSceneLoadOperation.sceneToLoad;
        SceneManager.LoadScene(currentSceneLoadOperation.sceneToLoad.name);
        OnFinishSceneLoad();
    }
    private static void OnFinishSceneLoad()
    {
        if(currentSceneLoadOperation.postOperationCall!=null) currentSceneLoadOperation.postOperationCall.Invoke();
        EventSystem.FireEvent(new OnFinishSceneLoadEvent(currentSceneLoadOperation));
    }

    public static StringSO GetCurrentScene() { return currentScene; }
}

[System.Serializable]
public class SceneLoadData
{
    public StringSO sceneToLoad;
    public UnityEvent postOperationCall;
    public bool isNetworkSceneLoad;

    public SceneLoadData(StringSO sceneToLoad, UnityEvent postOperationCall = null, bool isOnline = false)
    {
        this.sceneToLoad = sceneToLoad;
        this.postOperationCall = postOperationCall;
        this.isNetworkSceneLoad = isOnline;
    }
}
public class OnFinishSceneLoadEvent : EventInfo
{
    public SceneLoadData sceneLoadData = null;

    public OnFinishSceneLoadEvent(SceneLoadData sceneLoadData) { this.sceneLoadData = sceneLoadData; }
}
public class OnStartSceneLoadEvent : EventInfo { }