using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance { get; private set; }
    [System.Serializable]
    public class SFXArray
    {
        public string ArrayName;
        public AudioClip[] SFXs;
    }

    [SerializeField] private AudioSource SFXS;
    [SerializeField] private AudioSource ambientSource1, ambientSource2;
    private bool ambient2Playing;
    private bool changingAmbient;

    [SerializeField] private AudioSource musicSource;

    public float volSpd; 
    private float maxVolume;

    private MusicData quedMusic;

    private float measureLength;
    private float measureTimer;

    private void Awake()
    {
        instance = this;
        maxVolume = 1;
    }

    public void PlaySFX(SoundSO sfx)
    {
        //if (sfxCooling) return;

        SFXS.PlayOneShot(sfx.GetRandomClip());
    }

    public void ChangeMusic(AudioClip newMusic, float interval)
    {
        if(newMusic == musicSource.clip) { return; }
        quedMusic = new MusicData(newMusic, interval);
    }

    public void ChangeAmbient(AudioClip newAmbient)
    {
        if (ambient2Playing)
        {
            if (ambientSource2.clip != newAmbient)
            {
                ambientSource1.clip = newAmbient;
                ambientSource1.Play();
                changingAmbient = true;
            }
        }
        else
        {
            if (ambientSource1.clip != newAmbient)
            {
                ambientSource2.clip = newAmbient;
                ambientSource2.Play();
                changingAmbient = true;
            }
        }
    }
    public void UpdateAmbientSource(bool isMusicSource, float value)
    {
        if (isMusicSource)
        {
            maxVolume = value;
            if (ambient2Playing) { ambientSource2.volume = value; }
            else { ambientSource1.volume = value; }
        }
        else
        {
            SFXS.volume = value;
        }
    }

    private void Update()
    {
        if (changingAmbient)
        {
            if (ambient2Playing)
            {
                if (ambientSource1.volume <= maxVolume)
                {
                    ambientSource1.volume += volSpd * Time.deltaTime;
                }
                ambientSource2.volume -= volSpd * Time.deltaTime;
                if (ambientSource1.volume >= 1 && ambientSource2.volume <= 0)
                {
                    ambientSource2.clip = null;
                    ambientSource2.Stop();
                    changingAmbient = false;
                    ambient2Playing = false;
                }
            }
            else
            {
                if (ambientSource2.volume <= maxVolume)
                {
                    ambientSource2.volume += volSpd * Time.deltaTime;
                }
                ambientSource1.volume -= volSpd * Time.deltaTime;
                if (ambientSource2.volume >= 1 && ambientSource1.volume <= 0)
                {
                    ambientSource1.clip = null;
                    ambientSource1.Stop();
                    changingAmbient = false;
                    ambient2Playing = true;
                }
            }
        }

        measureTimer += Time.deltaTime;
        if(measureTimer > measureLength)
        {
            measureTimer = 0;
            if (quedMusic != null)
            {
                measureLength = quedMusic.interval;
                musicSource.clip = quedMusic.audio;
                musicSource.Play();

                quedMusic = null;
            }
        }
        
    }
}
public static class StaticAudioManager
{
    public static void PlaySFX(SoundSO sound)
    {
        if (AudioManager.instance == null) return;
        AudioManager.instance.PlaySFX(sound);
    }
    public static void ChangeMusic(AudioClip newMusic, float interval = 4)
    {
        if (AudioManager.instance == null) return;
        AudioManager.instance.ChangeMusic(newMusic, interval);
    }
    public static void ChangeAmbient(AudioClip newAmbient)
    {
        if (AudioManager.instance == null) return;
        AudioManager.instance.ChangeAmbient(newAmbient);
    }
}
[System.Serializable]
public class MusicData
{
    public AudioClip audio;
    public float interval;

    public MusicData(AudioClip audio, float interval)
    {
        this.audio = audio;
        this.interval = interval;
    }
}