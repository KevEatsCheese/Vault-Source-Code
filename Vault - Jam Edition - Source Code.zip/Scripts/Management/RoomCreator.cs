using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public static class RoomCreator
{
    public static void CreateRoom(StringSO scene)
    {
        FileStream stream = File.Create(Filepaths.GetSceneDirectory(Filepaths.SCENES_TEMPORARY_FOLDER_NAME) + @"\" + scene.name + Filepaths.EXTENSION_SCENE);
        BinaryFormatter formatter = new BinaryFormatter();
        SceneData data = new SceneData();

        data.scene = scene.name;

        formatter.Serialize(stream, data);
        stream.Close();
    }
    public static bool RoomExists(StringSO scene)
    {
        return File.Exists(Filepaths.GetSceneDirectory(Filepaths.SCENES_TEMPORARY_FOLDER_NAME) + @"\" + scene.name + Filepaths.EXTENSION_SCENE);
    }
}