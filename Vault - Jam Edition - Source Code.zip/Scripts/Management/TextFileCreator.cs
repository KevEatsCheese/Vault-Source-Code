using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using UnityEngine;

public static class TextFileCreator 
{
    public static void CreateTextFile(string name, string contents, bool permenant)
    {
        string path = "";
        if(permenant) { path = Filepaths.GetSceneDirectory(Filepaths.SCENES_PERMENANT_FOLDER_NAME); }
        else { path = Filepaths.GetSceneDirectory(Filepaths.SCENES_TEMPORARY_FOLDER_NAME); }

        FileStream stream = File.Create(path + @"\" + name + ".txt");
        StreamWriter writer = new StreamWriter(stream);
        writer.Write(contents);
        writer.Close();
        stream.Close();
    }
}
