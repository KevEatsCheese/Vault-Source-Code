using UnityEngine;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;

public class Loader : MonoBehaviour
{
    private const int EXTENSIONS_COUNT = 8;
    private List<FileExtensions> allExtensions = new List<FileExtensions>();

    private void Start()
    {
        //Load Persistant Data
        PersistantDataManager.Load();

        //Setup cave directory
        string temporarySceneDirectoryPath = Filepaths.GetSceneDirectory(Filepaths.SCENES_TEMPORARY_FOLDER_NAME);
        DirectoryInfo sceneDirectory = Directory.CreateDirectory(temporarySceneDirectoryPath);

        //Load Last Scene
        string filepath = Application.persistentDataPath + @"\" + Filepaths.LAST_SCENE_FILE_NAME;
        if (File.Exists(filepath))
        {
            BinaryFormatter saveDataFormatter = new BinaryFormatter();
            FileStream saveDataStream = File.Open(filepath, FileMode.Open);
            string lastSceneName = saveDataFormatter.Deserialize(saveDataStream) as string;
            saveDataStream.Close();
            StringSO[] allScenes = Resources.LoadAll<StringSO>(Filepaths.RESOURCES_SCENES_FOLDER_NAME);
            foreach(StringSO scene in allScenes)
            {
                if(scene.name == lastSceneName)
                {
                    StaticData.lastScene = scene;
                    break;
                }
            }
            
        }

        //Generate extensions list
        allExtensions.Clear();
        for(int i = 0; i < EXTENSIONS_COUNT; i++)
        {
            allExtensions.Add((FileExtensions)i);
        }

        //Generate response list
        BaseStartupResponse[] allResponses = Resources.LoadAll<BaseStartupResponse>(Filepaths.RESOURCES_STARTUP_RESPONSES_FOLDER_NAME);

        //Get file
        string[] args = Environment.GetCommandLineArgs();

        if(args.Length == 1) 
        {
            Debug.Log("?");
            return; 
        }

        //Get file extension type
        string[] fileTypeRaw = args[1].Split(".");
        string fileType = fileTypeRaw[fileTypeRaw.Length - 1];
        FileExtensions extension = StringToFileExtension(fileType);

        //Calculate Valid Responses
        List<BaseStartupResponse> validResponses = new List<BaseStartupResponse>();
        foreach(BaseStartupResponse response in allResponses)
        {
            if (response.IsValid(extension)) 
            {
                validResponses.Add(response);
            }
            else { continue; }
        }

        //Calculate Best Response
        if(validResponses.Count > 0)
        {
            BaseStartupResponse bestResponse = validResponses[0];
            foreach(BaseStartupResponse baseStartupResponse in validResponses)
            {
                if (bestResponse.GetPriority() > baseStartupResponse.GetPriority())
                {
                    bestResponse = baseStartupResponse;
                }
            }
            Debug.Log(bestResponse);
            bestResponse.Startup(extension, args[1]);
        }
    }
    private FileExtensions StringToFileExtension(string input)
    {
        foreach(FileExtensions fileExtension in allExtensions)
        {
            if (input == fileExtension.ToString())
            {
                return fileExtension;
            }
        }
        return FileExtensions.NULL;
    }
}
[Serializable]
public class SceneData
{
    public string scene;
}
public enum FileExtensions
{
    txt,
    mp4,
    wav,
    mp3,
    png,
    jpg,
    scene,
    NULL,
}