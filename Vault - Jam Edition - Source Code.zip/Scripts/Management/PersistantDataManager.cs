using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public static class PersistantDataManager 
{
    public static void Save()
    {
        FileStream fileStream = File.Create(Application.persistentDataPath + @"\" + Filepaths.PERSISTANT_DATA_FILE_NAME);
        BinaryFormatter formatter = new BinaryFormatter();
        SerializeablePersistantData data = new SerializeablePersistantData();

        data.foundEndings = SerializeEndings(PersistantData.foundEndings);
        data.conditions = SaveConditions();

        formatter.Serialize(fileStream, data);
        fileStream.Close();
    }
    public static void Load()
    {
        string path = Application.persistentDataPath + @"\" + Filepaths.PERSISTANT_DATA_FILE_NAME;
        if(!File.Exists(path)) { return; }
        FileStream fileStream = File.Open(path, FileMode.Open);
        BinaryFormatter formatter = new BinaryFormatter();
        SerializeablePersistantData data = formatter.Deserialize(fileStream) as SerializeablePersistantData;
        fileStream.Close();

        PersistantData.foundEndings = DeserializeEndings(data.foundEndings);
        Conditions.LoadAllConditions(data.conditions);
    }
    public static void Delete()
    {
        string path = Application.persistentDataPath + @"\" + Filepaths.PERSISTANT_DATA_FILE_NAME;
        if (!File.Exists(path)) { return; }

        File.Delete(path);
    }

    private static List<SerializableCondition> SaveConditions()
    {
        List<SerializableCondition> savableConditions = new List<SerializableCondition>();
        ConditionSO[] conditions = Resources.LoadAll<ConditionSO>("Conditions");
        foreach (Condition condition in Conditions.GetAllConditions())
        {
            SerializableCondition savableCondition = new SerializableCondition();
            savableCondition.conditionStatus = condition.conditionStatus;
            foreach (ConditionSO conditionSO in conditions)
            {
                if (condition.condition == conditionSO)
                {
                    savableCondition.conditionName = conditionSO.name;
                    savableConditions.Add(savableCondition);
                    break;
                }
            }
        }
        return savableConditions;
    }
    private static string SerializeEndings(List<EndingSO> endings)
    {
        string data = "";
        for(int i =  0; i < endings.Count; i++)
        {
            data += endings[i].name;
            if(i < endings.Count - 1) { data += DataSeperators.SEPERATOR_1; }
        }
        return data;
    }
    private static List<EndingSO> DeserializeEndings(string data)
    {
        List<EndingSO> endings = new List<EndingSO>();
        EndingSO[] allEndings = Resources.LoadAll<EndingSO>(Filepaths.RESOURCES_ENDINGS_FOLDER_NAME);
        string[] endingStrings = data.Split(DataSeperators.SEPERATOR_1);

        foreach(string endingString in endingStrings)
        {
            foreach(EndingSO ending in allEndings)
            {
                if(endingString == ending.name)
                {
                    endings.Add(ending);
                    break;
                }
            }
        }

        return endings;
    }
}
public static class PersistantData
{
    public static List<EndingSO> foundEndings = new List<EndingSO>();
}
[System.Serializable]
public class SerializeablePersistantData
{
    public string foundEndings;
    public List<SerializableCondition> conditions = new List<SerializableCondition>();
}