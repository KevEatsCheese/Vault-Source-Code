using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using System.IO;
public class ContentComplete : BaseStartupResponse
{
    public override void Startup(FileExtensions fileExtension, string filepath)
    {
        base.Startup(fileExtension, filepath);
        PersistantDataManager.Delete();
        Directory.Delete(Filepaths.GetSceneDirectory(Filepaths.SCENES_TEMPORARY_FOLDER_NAME), true);

    }
    public override bool IsValid(FileExtensions fileExtension)
    {
        if(PersistantData.foundEndings.Count != Resources.LoadAll<EndingSO>(Filepaths.RESOURCES_ENDINGS_FOLDER_NAME).Length) { return false; }
        return base.IsValid(fileExtension);
    }
}
