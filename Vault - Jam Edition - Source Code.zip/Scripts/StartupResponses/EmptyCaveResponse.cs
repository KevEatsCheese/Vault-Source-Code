using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public class EmptyCaveResponse : BaseStartupResponse
{
    public override void Startup(FileExtensions fileExtension, string filepath)
    {
        FileStream caveDataStream = File.Open(filepath, FileMode.Open);
        StreamReader reader = new StreamReader(caveDataStream);
        if(reader.ReadToEnd().Length > 0)
        {
            caveDataStream.Close();
            return;
        }

        caveDataStream.Close();
        LoadNextCave();
    }
    public override bool IsValid(FileExtensions fileExtension)
    {
        if (!base.IsValid(fileExtension)) { return false; } 
        if (RoomCreator.RoomExists(GetNextCave())) { return false; }
        return true;
    }
}
