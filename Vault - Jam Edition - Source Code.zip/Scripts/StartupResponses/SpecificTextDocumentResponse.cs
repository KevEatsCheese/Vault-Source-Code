using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public class SpecificTextDocumentResponse : BaseStartupResponse
{
    [SerializeField] private string fileNameReq;
    [SerializeField] private string contentReq;
    [SerializeField] private bool isCaseSensitive;

    public override void Startup(FileExtensions fileExtension, string filepath)
    {
        if(!isCaseSensitive)
        {
            fileNameReq = fileNameReq.ToUpper();
            contentReq = contentReq.ToUpper();
        }

        //Is name good
        string[] pathSegments = filepath.Split(@"\");
        string fileName = pathSegments[pathSegments.Length - 1].Substring(0, pathSegments[pathSegments.Length-1].Length-fileExtension.ToString().Length);
        StaticBuildDebugger.Debug(fileName);
        if(!isCaseSensitive) { fileName = fileName.ToUpper(); }

        if(fileName != fileNameReq && fileNameReq.ToUpper() != "NULL") { return; }

        //Is content good
        FileStream fileStream = File.OpenRead(filepath);
        StreamReader sr = new StreamReader(fileStream);
        string contents = sr.ReadToEnd();
        StaticBuildDebugger.Debug(contents);
        if(!isCaseSensitive) { contents = contents.ToUpper(); }

        if(contents.Trim() != contentReq && contentReq.ToUpper() != "NULL") { return; }

        LoadNextCave();
    }
}
