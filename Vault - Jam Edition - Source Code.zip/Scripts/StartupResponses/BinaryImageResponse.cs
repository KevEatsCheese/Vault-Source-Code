using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class BinaryImageResponse : BaseStartupResponse
{
    [SerializeField] private Texture2D solution;
    private Texture2D tex;
    public override void Startup(FileExtensions fileExtension, string filepath)
    {
        byte[] bytes = File.ReadAllBytes(filepath);
        tex = new Texture2D(solution.width, solution.height);
        tex.LoadImage(bytes);
        
        if(solution.GetRawTextureData() != tex.GetRawTextureData()) { return; }

        LoadNextCave();
    }
}
