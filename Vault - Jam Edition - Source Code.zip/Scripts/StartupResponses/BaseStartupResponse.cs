using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using System;
public class BaseStartupResponse : MonoBehaviour
{
    [Tooltip("Lower the better")]
    [SerializeField] private int priority;

    [SerializeField] private StringSO lastSceneReq;
    [SerializeField] private FileExtensions[] extensionReqs;

    [SerializeField] private StringSO nextScene;
    [SerializeField] private SceneLoadBehaviours sceneLoadBehaviour;

    public virtual void Startup(FileExtensions fileExtension, string filepath)
    {
        LoadNextCave();
    }
    public virtual bool IsValid(FileExtensions fileExtension)
    {
        if (lastSceneReq != null && StaticData.lastScene != lastSceneReq) { return false; }

        if (extensionReqs.Length > 0)
        {
            bool foundOne = false;
            foreach (FileExtensions ext in extensionReqs)
            {
                if (ext == fileExtension)
                {
                    foundOne = true;
                    break;
                }
            }
            if(!foundOne) { return false; }
        }
        return true;
    }

    public void LoadNextCave()
    {
        switch(sceneLoadBehaviour)
        {
            case SceneLoadBehaviours.CREATE_FILE:
                RoomCreator.CreateRoom(nextScene);
                Application.Quit();
                break;
            case SceneLoadBehaviours.LOAD_SCENE:
                TKSceneManager.LoadScene(new SceneLoadData(nextScene));
                break;
        }
        
    }
    public StringSO GetNextCave() { return nextScene; }
    public int GetPriority() { return priority; }

    #region Update Window Name
    [DllImport("user32.dll", EntryPoint = "SetWindowText", CharSet = CharSet.Unicode)]
    public static extern bool SetWindowText(IntPtr hwnd, string lpString);
    [DllImport("user32.dll", EntryPoint = "FindWindow", CharSet = CharSet.Unicode)]
    public static extern System.IntPtr FindWindow(String className, System.String windowName);

    public void SetWindowName(string windowName)
    {
        StaticBuildDebugger.Debug(windowName);
        //Get the window handle.
        IntPtr windowPtr = FindWindow(null, "ENTRANCE");
        //Set the title text using the window handle.
        SetWindowText(windowPtr, windowName);
    }
    #endregion
}
public enum SceneLoadBehaviours
{
    CREATE_FILE,
    LOAD_SCENE,
    DO_NOTHING
}