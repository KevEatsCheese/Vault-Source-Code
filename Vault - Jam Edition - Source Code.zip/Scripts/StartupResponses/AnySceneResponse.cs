using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public class AnySceneResponse : BaseStartupResponse
{
    public override void Startup(FileExtensions fileExtension, string filepath)
    {
        BinaryFormatter sceneDataFormatter = new BinaryFormatter();
        FileStream sceneDataStream = File.Open(filepath, FileMode.Open);
        SceneData roomData = sceneDataFormatter.Deserialize(sceneDataStream) as SceneData;
        sceneDataStream.Close();

        StringSO[] allScenes = Resources.LoadAll<StringSO>(Filepaths.RESOURCES_SCENES_FOLDER_NAME);
        foreach (StringSO scene in allScenes)
        {
            if(scene.name == roomData.scene)
            {
                SetWindowName(scene.name);
                TKSceneManager.LoadScene(new SceneLoadData(scene));
                return;
            }
        }
    }
    public override bool IsValid(FileExtensions fileExtension)
    {
        return base.IsValid(fileExtension);
    }
}
