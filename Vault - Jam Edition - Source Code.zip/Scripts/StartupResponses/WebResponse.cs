using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WebResponse : BaseStartupResponse
{
    [SerializeField] private StringSO webScene;
    public override void Startup(FileExtensions fileExtension, string filepath)
    {
        TKSceneManager.LoadScene(new SceneLoadData(webScene));
    }
    public override bool IsValid(FileExtensions fileExtension)
    {
        StaticBuildDebugger.Debug(Application.platform.ToString());
        return Application.platform == RuntimePlatform.WebGLPlayer;
    }
}
