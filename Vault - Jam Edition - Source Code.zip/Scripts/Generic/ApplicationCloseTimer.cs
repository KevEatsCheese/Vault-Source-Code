using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ApplicationCloseTimer : MonoBehaviour
{
    [SerializeField] private float time;
    [SerializeField] private Slider timerVisual;
    private float timer;

    private void Awake()
    {
        timerVisual.maxValue = time;
        timerVisual.value = time;
    }
    private void Update()
    {
        timer += Time.deltaTime;
        timerVisual.value -= Time.deltaTime;
        if (timer >= time)
        {
            Debug.Log("close");
            Application.Quit();
        }
    }
}
