using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenURL : MonoBehaviour
{
    [SerializeField] private string URL;

    public void Open()
    {
        Application.OpenURL(URL);
    }
    public void ChooseURL(string url)
    {
        Application.OpenURL(url);
    }
}
