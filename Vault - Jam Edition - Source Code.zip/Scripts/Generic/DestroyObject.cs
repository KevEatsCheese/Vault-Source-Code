using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObject : MonoBehaviour
{
    [SerializeField] private GameObject obj;

    public void Trigger()
    {
        Destroy(obj);
    }
    public void Choose(GameObject target)
    {
        Destroy(target);
    }
}
