using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayAmbient : MonoBehaviour
{
    public AudioClip ambient;

    public void Trigger()
    {
        StaticAudioManager.ChangeAmbient(ambient);
    }
    public void Choose(AudioClip newAmbient)
    {
        StaticAudioManager.ChangeAmbient(newAmbient);
    }
}
