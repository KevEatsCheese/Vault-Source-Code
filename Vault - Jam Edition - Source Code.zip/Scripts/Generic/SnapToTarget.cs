using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnapToTarget : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector2 offset;

    private void Start()
    {
        offset = transform.localPosition;
    }
    private void Update()
    {
        Vector3 desiredPosition = target.position + (Vector3)offset;
        if (Vector2.Distance(desiredPosition, transform.position) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(transform.position, desiredPosition, 10);
        }
        if (GetComponent<Rigidbody2D>() != null)
        {
            if (GetComponent<Rigidbody2D>().velocity.magnitude > 1) { GetComponent<Rigidbody2D>().velocity = GetComponent<Rigidbody2D>().velocity.normalized; }
        }
    }
}
