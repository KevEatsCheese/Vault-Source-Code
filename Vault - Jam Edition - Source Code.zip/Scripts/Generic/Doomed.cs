using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Doomed : MonoBehaviour
{
    [SerializeField] private float lifespan;

    private void Awake()
    {
        Destroy(gameObject,lifespan);
    }
}
