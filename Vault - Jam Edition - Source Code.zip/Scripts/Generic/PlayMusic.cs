using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayMusic : MonoBehaviour
{
    [SerializeField] private AudioClip song;

    public void Trigger()
    {
        StaticAudioManager.ChangeMusic(song);
    }
    public void Choose(AudioClip clip)
    {
        StaticAudioManager.ChangeAmbient(clip);
    }
}
