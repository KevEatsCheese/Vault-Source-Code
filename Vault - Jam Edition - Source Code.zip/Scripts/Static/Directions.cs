using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Directions 
{
    public static Vector2Int[] GetAllDirections(bool justCardinal)
    {
        if(justCardinal)
        {
            return new Vector2Int[]
            {
            new Vector2Int(0,1),
            new Vector2Int(1,0),
            new Vector2Int(0,-1),
            new Vector2Int(-1,0),
            };
        }
        return new Vector2Int[]
        {
            new Vector2Int(0,1),
            new Vector2Int(1,1),
            new Vector2Int(1,0),
            new Vector2Int(1,-1),
            new Vector2Int(0,-1),
            new Vector2Int(-1,-1),
            new Vector2Int(-1,0),
            new Vector2Int(-1,1),
        };
    }
}
