using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StaticFunctions 
{
    public static void DestroyChildren(Transform subject)
    {
        foreach(Transform child in subject)
        {
            MonoBehaviour.Destroy(child.gameObject);
        }
    }
    public static Vector2 Vector3IntToVector2(Vector3Int vector3Int)
    {
        return new Vector2(vector3Int.x, vector3Int.y);
    }
    public static Vector3Int Vector2ToVector3Int(Vector2 vector2)
    {
        int x = Mathf.RoundToInt(vector2.x);
        int y = Mathf.RoundToInt(vector2.y);
        int z = Mathf.RoundToInt(0);
        return new Vector3Int(x, y, z);
    }

    public static Vector2 LeastDistance(Vector2 subject, List<Vector2> options)
    {
        Vector2 bestOption = Vector2.one * 420000;
        foreach(Vector2 option in options)
        {
            if (option == subject) continue;
            if(Vector2.Distance(subject, bestOption) > Vector2.Distance(subject, option))
            {
                bestOption = option;
            }
        }
        return bestOption;
    }

    public static Vector2 RandomDirection()
    {
        float x = Random.Range(-1f, 1f);
        float y = Random.Range(-1f, 1f);
        return new Vector2 (x, y);
    }
}
