using UnityEngine;

public static class SerializableVector
{
    public static Vector3 DeserializeVector3(S_Vector3 vector3)
    {
        return new Vector3(vector3.x, vector3.y, vector3.z);    
    }
    public static Vector2 DeserializeVector2(S_Vector2 vector2)
    {
        return new Vector2(vector2.x, vector2.y);
    }
}

[System.Serializable]
public class S_Vector3
{
    public float x;
    public float y;
    public float z;

    public S_Vector3(Vector3 vector)
    {
        x = vector.x;
        y = vector.y;
        z = vector.z;
    }
}

[System.Serializable]
public class S_Vector2
{
    public float x;
    public float y;

    public S_Vector2(Vector2 vector)
    {
        x = vector.x;
        y = vector.y;
    }
}