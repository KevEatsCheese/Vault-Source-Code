using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseInteractible : MonoBehaviour
{
    [SerializeField] private string prompt;
    private bool isInteractible = true;

    public virtual void Interact(GameObject user)
    {
        if (!isInteractible) { return; }
        InteractibleUI.instance.HidePrompt();

        EventSystem.FireEvent(new OnInteractEvent(isInteractible));
    }
    public virtual void OnSelect()
    {
        if(!isInteractible) { return; }
        InteractibleUI.instance.ShowPrompt(prompt);
    }
    public virtual void OnDeselect()
    {
        InteractibleUI.instance.HidePrompt();
    }
    public void SetPrompt(string value) { prompt = value; }

    public bool GetIsInteractible() { return isInteractible; }
    public void SetIsInteractible(bool value)
    {
        isInteractible = value;
        if(!isInteractible) { OnDeselect(); }
    }
}
public class OnInteractEvent : EventInfo
{
    public bool stillInteractible;
    public OnInteractEvent(bool stillInteractible)
    {
        this.stillInteractible = stillInteractible;
    }
}
